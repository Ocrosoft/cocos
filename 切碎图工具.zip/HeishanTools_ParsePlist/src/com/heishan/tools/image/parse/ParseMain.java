package com.heishan.tools.image.parse;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.filechooser.FileFilter;

import com.heishan.tools.log.Log;

public class ParseMain extends JFrame implements ActionListener {
	
	public static final String VERSION = "V2.0";
	
	private static final String FRAMES = "frames";
	private static final String FRAME = "frame";
	private static final String SOURCE_SIZE = "sourceSize";
	private static final String OFFSET = "offset";
	private static final String SOURCE_COLOR_RECT = "sourceColorRect";
	private static final String ROTATED = "rotated";
	private static final String SPLIT = ",";
	
	/**
	 * 程序入口
	 * @param args
	 */
	public static void main(String[] args) {
		// 启动模拟器
		new Thread(new Runnable() {
			@Override
			public void run() {
				new ParseMain();
			}}).start();
	}
	
	//private static final int FONT_SIZE = 30; // 字体大小
	private static final int FRAME_WIDTH = 600; // 窗口宽度
	private static final int FRAME_HEIGHT = 450; // 窗口高度
	private static final long serialVersionUID = 1L; // 其它
	
	private JTextField	textFieldPlist, // plist路径
	   				   	textFieldPng, // png路径
	   				   	textFieldOutPath; // 输出路径
	private JButton btnPlist, // 打开plist路径
				    btnPng, // 打开png路径
				    btnOutPath, // 打开输出路径
				    btnParse; // 解析文件
	
	/**
	 * 构造函数
	 */
	private ParseMain() {
		this.setTitle("plist文件解析工具" + VERSION);
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocation(100, 100);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.initPanelConfig();
		this.setVisible(true);
		this.setResizable(false);
		this.setBackground(Color.GRAY);
		
		this.initAbout();
	}
	
	private void initAbout() {  
		JToolBar toolBar = new JToolBar("JToolBar");
		JButton btnAbout = new JButton("About");
		toolBar.add(btnAbout);
		btnAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Author: 黑山老妖");
			}
		});        
		this.add(toolBar, BorderLayout.NORTH);
		toolBar.setVisible(true);
		toolBar.setFloatable(false);
	}
	
	private void initPanelConfig() {
		// 创建顶部
		Panel panelConfig = new Panel(new GridLayout(9, 1));
		
		// plist 文件
		JLabel labelPlist = new JLabel("  plist文件路径:");
		panelConfig.add(labelPlist);
		Panel panelPlist = new Panel(new BorderLayout());
		this.textFieldPlist = new JTextField();
		panelPlist.add(this.textFieldPlist);
		this.btnPlist = new JButton("打开");
		this.btnPlist.addActionListener(this);
		panelPlist.add(this.btnPlist, BorderLayout.EAST);
		panelConfig.add(panelPlist);
		panelPlist.setVisible(true);
		
		// png 文件
		JLabel labelPng = new JLabel("  png文件路径:");
		panelConfig.add(labelPng);
		Panel panelPng = new Panel(new BorderLayout());
		this.textFieldPng = new JTextField();
		panelPng.add(this.textFieldPng);
		this.btnPng = new JButton("打开");
		this.btnPng.addActionListener(this);
		panelPng.add(this.btnPng, BorderLayout.EAST);
		panelConfig.add(panelPng);
		panelPng.setVisible(true);
		
		// 输出文件路径
		JLabel labelOutPath = new JLabel("  输出文件路径:");
		panelConfig.add(labelOutPath);
		Panel panelOutPath = new Panel(new BorderLayout());
		this.textFieldOutPath = new JTextField("./image_out");
		panelOutPath.add(this.textFieldOutPath);
		this.btnOutPath = new JButton("打开");
		this.btnOutPath.addActionListener(this);
		panelOutPath.add(this.btnOutPath, BorderLayout.EAST);
		panelConfig.add(panelOutPath);
		panelOutPath.setVisible(true);
		
		// 添加空行
		panelConfig.add(new JLabel());
		
		// 添加 按钮
		Panel panelBtn = new Panel(new GridLayout(1, 3));
		panelBtn.add(new JLabel());
		this.btnParse = new JButton("解析plist");
		this.btnParse.addActionListener(this);
		panelBtn.add(this.btnParse);
		panelBtn.add(new JLabel());
		panelConfig.add(panelBtn);
		panelBtn.setVisible(true);
		
		// 帮助信息
		Panel panelHelp = new Panel(new BorderLayout());
		JTextArea textAreaHelp = new JTextArea();
		textAreaHelp.setLineWrap(true);
		textAreaHelp.append("使用说明:\n");
		textAreaHelp.append("1.本软件的功能是将plist和对应的png文件解析成散碎的图片，很多开发者喜欢从别的应用程序中抽取素材，本软件的诞生正是为了方便此类开发者。\n");
		textAreaHelp.append("2.设置plist文件路径，设置png文件路径，设置输出文件路径，点击“解析plist”按钮开始解析，解析后生成的png散碎图片将在输出文件路径中生成。\n");
		textAreaHelp.append("3.本软件不支持二进制编码的plist文件，从ios应用程序中解析出的plist文件很多是被二进制编码的，需要使用第三方plist编辑器进行解码，比如Property List Editor。\n");
		textAreaHelp.append("4.本软件不支持压缩格式的png图片，从ios应用中解析出的png图片很多是被压缩过的，在windows下查看是黑色图片，且无法使用PhotoShop直接打开，此类png只需要使用mac自带的图片浏览器打开，然后另存为png即可解决。\n");
		textAreaHelp.setEditable(false);
		textAreaHelp.setBounds(5, 0, FRAME_WIDTH - 10, FRAME_HEIGHT / 2);
		textAreaHelp.setFocusable(false);
		textAreaHelp.setBackground(this.getBackground());
		panelHelp.add(textAreaHelp, BorderLayout.CENTER);
				
		panelHelp.add(new JLabel("  "), BorderLayout.WEST);
		panelHelp.add(new JLabel(""), BorderLayout.EAST);
				
		this.add(panelHelp, BorderLayout.SOUTH);
		panelHelp.setVisible(true);
		
		this.add(panelConfig, BorderLayout.CENTER);
		panelConfig.setVisible(true);
	}
	
	/**
	 * 切割xml、png
	 * @param xmlFileName
	 * @param pngFileName
	 */
	public static void cutXmlPng(String xmlFileName, String pngFileName) {
		String path = System.getProperty("user.dir") + "/";
		String inPath = path + "image_in/";
		String outPath = path + "image_out/";
		String xmlPath = inPath + xmlFileName;
		String pngPath = inPath + pngFileName;
		
		ParseXml xml = new ParseXml();
		Map<String, ParseRect> map = xml.parserXml(xmlPath);
		if (map != null) {
			for(String key : map.keySet()) {
				ParseUtil.cutImage(map.get(key).x, map.get(key).y, map.get(key).width, map.get(key).height, pngPath, outPath + key + ".png");
				/* 忍者钓鱼
				ImageUtil.cutImage(map.get(key).x/2, map.get(key).y/2, map.get(key).width/2, map.get(key).height/2, pngPath, outPath + key + ".png");
				*/
			}
		} else {
			Log.debug("解析xml获得的map是空的");
		}
	}
	
	/**
	 * 切割plist、png
	 * @param fileName
	 */
	@SuppressWarnings("unchecked")
	public static void cutPlistPng(String plistFileName, String pngFileName, String outPath) {
		//String path = System.getProperty("user.dir") + "/";
		//String inPath = path + "image_in/";
		//String outPath = path + "image_out/";
		//String plistPath = inPath + plistFileName;
		//String inFile = inPath + pngFileName;
		
		ParsePlist imagePlist = new ParsePlist();
		Map<String, Object> map = imagePlist.parserPlist(plistFileName);
		List<String> dictKeys = imagePlist.getDictKeys();
		if (dictKeys.contains(FRAMES) == false ||
				dictKeys.contains(FRAME) == false ||
				dictKeys.contains(SOURCE_SIZE) == false ||
				dictKeys.contains(OFFSET) == false ||
				dictKeys.contains(SOURCE_COLOR_RECT) == false ||
				dictKeys.contains(ROTATED) == false) {
			Log.error("自定义解析key与plist描述文件不符，无法进行解析!");
			return;
		}
		if (map != null) {
			//Map<String, Object> metadata = (Map<String, Object>) map.get("metadata");
			//Log.debug("realTextureFileName=" + metadata.get("realTextureFileName"));
			//Log.debug("textureFileName=" + metadata.get("textureFileName"));
			//Log.debug("smartupdate=" + metadata.get("smartupdate"));
			//Log.debug("size=" + metadata.get("size"));
			
			Map<String, Object> frames = (Map<String, Object>) map.get(FRAMES);
			for (String name : frames.keySet()) {
				Log.debug("name=" + name);
				String outFile = outPath + name;
				
				//@lili
				File file = new File(outFile).getParentFile();
				Log.debug("outDir=" + file);
				//如果文件夹不存在则创建
				if (!file.exists() || !file.isDirectory()) {
					file.mkdirs();
				}
				
				Map<String, Object> config = (Map<String, Object>) frames.get(name);
				Log.debug("frame=" + config.get(FRAME));
				Log.debug("sourceSize=" + config.get(SOURCE_SIZE));
				Log.debug("offset=" + config.get(OFFSET));
				Log.debug("sourceColorRect=" + config.get(SOURCE_COLOR_RECT));
				Log.debug("rotated=" + config.get(ROTATED));
				
				// plist中图片的位置和大小，解析如 {{124,30},{52,48}} 的字符串
				String frame = ((String) config.get(FRAME)).trim();
				String[] arrayFrame = frame.split(SPLIT);
				int frameX = Integer.valueOf(arrayFrame[0].substring(2));
				int frameY = Integer.valueOf(arrayFrame[1].substring(0, arrayFrame[1].indexOf("}")));
				int frameWidth = Integer.valueOf(arrayFrame[2].substring(1));
				int frameHeight = Integer.valueOf(arrayFrame[3].substring(0, arrayFrame[3].indexOf("}}")));
				//Log.debug("frameX=" + frameX + ", frameY=" + frameY + ", frameWidth=" + frameWidth + ", frameHeight=" + frameHeight);
				
				// plist中图片的偏移量，解析如 {2,-1} 的字符串
				String offset = ((String) config.get(OFFSET)).trim();
				String[] arrayOffset = offset.split(SPLIT);
				int offsetX = Integer.valueOf(arrayOffset[0].substring(1));
				int offsetY = Integer.valueOf(arrayOffset[1].substring(0, arrayOffset[1].indexOf("}")));
				//Log.debug("offsetX=" + offsetX + ", offsetY=" + offsetY);
				
				// 原始图片大小，解析如 {54,61} 的字符串
				String sourceSize = ((String) config.get(SOURCE_SIZE)).trim();
				String[] arraySourceSize = sourceSize.split(SPLIT);
				int sourceSizeWidth = Integer.valueOf(arraySourceSize[0].substring(1));
				int sourceSizeHeight = Integer.valueOf(arraySourceSize[1].substring(0, arraySourceSize[1].indexOf("}")));
				//Log.debug("sourceSizeWidth=" + sourceSizeWidth + ", sourceSizeHeight=" + sourceSizeHeight);
				
				// 是否旋转，解析如 false 的数据
				boolean rotated = (Boolean) config.get(ROTATED);
				//Log.debug("rotated=" + rotated);
				
				// 未知，解析如 {{0,6},{54,55}} 的字符串
				String sourceColorRect = ((String) config.get(SOURCE_COLOR_RECT)).trim();
				String[] arraySourceColorRect = sourceColorRect.split(SPLIT);
				int sourceColorRectX = Integer.valueOf(arraySourceColorRect[0].substring(2));
				int sourceColorRectY = Integer.valueOf(arraySourceColorRect[1].substring(0, arraySourceColorRect[1].indexOf("}")));
				int sourceColorRectWidth = Integer.valueOf(arraySourceColorRect[2].substring(1));
				int sourceColorRectHeight = Integer.valueOf(arraySourceColorRect[3].substring(0, arraySourceColorRect[3].indexOf("}}")));
				//Log.debug("sourceColorRectX=" + sourceColorRectX + ", sourceColorRectY=" + sourceColorRectY + ", sourceColorRectWidth=" + sourceColorRectWidth + ", sourceColorRectHeight=" + sourceColorRectHeight);
				
				ParseUtil.cutImage(pngFileName, outFile, rotated, frameX, frameY, frameWidth, frameHeight, offsetX, offsetY, sourceSizeWidth, sourceSizeHeight, sourceColorRectX, sourceColorRectY, sourceColorRectWidth, sourceColorRectHeight);
			}
		} else {
			Log.debug("解析plist获得的map是空的");
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == this.btnPlist) {
			FileFilter ff = new FileFilter() {
				@Override
				public boolean accept(File file) {
					if (file.getName().endsWith(".plist")) {
						return true;
					} else if (file.isDirectory()) {
						return true;
					}
					return false;
				}
				@Override
				public String getDescription() {
					return null;
				}};
			
			JFileChooser fc = new JFileChooser();
			fc.setFileFilter(ff);
			fc.setCurrentDirectory(new File("."));
			fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fc.showOpenDialog(null);
			
			File file = fc.getSelectedFile();
			if (file != null) {
				this.textFieldPlist.setText(file.getAbsolutePath());
				
				if (this.textFieldPng.getText() == "" || this.textFieldPng.getText().equals("")) {
					
				}
				
				String pngpath = file.getAbsolutePath().substring(0, file.getAbsolutePath().length() - 6) + ".png";
				this.textFieldPng.setText(pngpath);
			}
		} else if (ae.getSource() == this.btnPng) {
			FileFilter ff = new FileFilter() {
				@Override
				public boolean accept(File file) {
					if (file.getName().endsWith(".png")) {
						return true;
					} else if (file.isDirectory()) {
						return true;
					}
					return false;
				}
				@Override
				public String getDescription() {
					return null;
				}};
			
			JFileChooser fc = new JFileChooser();
			fc.setFileFilter(ff);
			fc.setCurrentDirectory(new File("."));
			fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fc.showOpenDialog(null);
			
			File file = fc.getSelectedFile();
			if (file != null) {
				this.textFieldPng.setText(file.getAbsolutePath());
			}
		} else if (ae.getSource() == this.btnOutPath) {
			JFileChooser fc = new JFileChooser();
			fc.setCurrentDirectory(new File("."));
			fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			fc.showOpenDialog(null);
			File file = fc.getSelectedFile();
			if (file != null) {
				Log.debug("输出文件路径: " + file.getAbsolutePath());
				this.textFieldOutPath.setText(file.getAbsolutePath());
			}
		} else if (ae.getSource() == this.btnParse) {
			if (this.textFieldPlist.getText() == "" || this.textFieldPlist.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "plist文件路径为空", "错误提示", JOptionPane.ERROR_MESSAGE);
			} else if (this.textFieldPng.getText() == "" || this.textFieldPng.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "png文件路径为空", "错误提示", JOptionPane.ERROR_MESSAGE);
			} else {
				if (!new File(this.textFieldPlist.getText()).exists()) {
					JOptionPane.showMessageDialog(null, "plist文件不存在", "错误提示", JOptionPane.ERROR_MESSAGE);
				} else if (!new File(this.textFieldPng.getText()).exists()) {
					JOptionPane.showMessageDialog(null, "png文件不存在", "错误提示", JOptionPane.ERROR_MESSAGE);
				} else {
					if (new File(this.textFieldOutPath.getText()).exists()) {
						if (new File(this.textFieldOutPath.getText()).isFile()) {
							new File(this.textFieldOutPath.getText()).delete();
							new File(this.textFieldOutPath.getText()).mkdir();
						}
					} else {
						new File(this.textFieldOutPath.getText()).mkdir();
					}
					
					String plistPath = this.textFieldPlist.getText();
					String pngPath = this.textFieldPng.getText();
					String outPath = this.textFieldOutPath.getText() + "/";
					
					cutPlistPng(plistPath, pngPath, outPath);
					JOptionPane.showMessageDialog(null, "plist解析完毕！", "完成提示", JOptionPane.PLAIN_MESSAGE);
				}
			}
		}
	}

}
