package com.heishan.tools.image.parse;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.heishan.tools.log.Log;

public class ParseXml {
	
	/**
	 * 解析xml
	 * @param fileName
	 * @return
	 */
	public Map<String, ParseRect> parserXml(String fileName) {
		SAXParserFactory saxfac = SAXParserFactory.newInstance();
		try {
			SAXParser saxparser = saxfac.newSAXParser();
			InputStream is = new FileInputStream(fileName);
			Map<String, ParseRect> map = new HashMap<String, ParseRect>();
			saxparser.parse(is, new XmlSAXHandler(map));
			/*
			for(String key : map.keySet()) {
				Log.debug(key);
				Log.debug(map.get(key).toString());
			}
			*/
			return map;
		} catch (ParserConfigurationException e) {
			Log.error(e.getLocalizedMessage());
		} catch (SAXException e) {
			Log.error(e.getLocalizedMessage());
		} catch (FileNotFoundException e) {
			Log.error(e.getLocalizedMessage());
		} catch (IOException e) {
			Log.error(e.getLocalizedMessage());
		}
		return null;
	}
}

class XmlSAXHandler extends DefaultHandler {
	boolean hasAttribute = false;
	Attributes attributes = null;
	Map<String, ParseRect> map;

	public XmlSAXHandler(Map<String, ParseRect> map) {
		this.map = map;
	}

	public void startDocument() throws SAXException {
		// Log.debug("文档开始打印了");
	}

	public void endDocument() throws SAXException {
		// Log.debug("文档打印结束了");
	}

	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("SpriteData")) {
			return;
		}
		if (qName.equals("Sprite")) {
			//Log.debug(qName);
		}
		if (attributes.getLength() > 0) {
			this.attributes = attributes;
			this.hasAttribute = true;
		}
	}

	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (hasAttribute && (attributes != null)) {
			/*
			for (int i = 0; i < attributes.getLength(); i++) {
				Log.debug(attributes.getQName(i) + " : " + attributes.getValue(i));
			}
			*/
			String key = attributes.getValue(0);
			String value = attributes.getValue(1);
			String[] array = value.split(",");
			ParseRect rect = new ParseRect(Integer.valueOf(array[0]), Integer.valueOf(array[1]), 
					Integer.valueOf(array[2]) - Integer.valueOf(array[0]), 
					Integer.valueOf(array[3]) - Integer.valueOf(array[1]));
			//Log.debug(key);
			//Log.debug(rect.toString());
			this.map.put(key, rect);
		}
	}

	public void characters(char[] ch, int start, int length) throws SAXException {
		//Log.debug(new String(ch, start, length));
	}

}
