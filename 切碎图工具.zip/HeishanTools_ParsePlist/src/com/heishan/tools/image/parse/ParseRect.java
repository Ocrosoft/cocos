package com.heishan.tools.image.parse;


public class ParseRect {
	
	public int x;
	public int y;
	public int width;
	public int height;
	
	public ParseRect() {}
	
	public ParseRect(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	@Override
	public String toString() {
		return "x=" + this.x + ", y=" + this.y + ", width=" + this.width + ", height=" + this.height;
	}

}
