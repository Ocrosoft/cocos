package com.heishan.tools.image.parse;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import com.heishan.tools.log.Log;

public class ParseUtil {
	
	/**
	 * 切割图片
	 * 
	 * @param rowNum 切为几行
	 * @param columnNum 切为几列
	 * @param inFile 输入图片
	 * @param outPath 输出图片
	 */
	public static void cutImage(int rowNum, int columnNum, String inFileName, String outPathName) {
		try {
			if (rowNum <= 0 || columnNum <= 0) {
				Log.error("unexpect rowNum=" + rowNum + ", columnNum=" + columnNum);
				return;
			}
			
			File inFile = new File(inFileName);
			BufferedImage biIn = ImageIO.read(inFile);
			int srcWidth = biIn.getWidth(); // 得到源图宽
			int srcHeight = biIn.getHeight(); // 得到源图长
			int singleWidth = srcWidth / columnNum;
			int singleHeight = srcHeight / rowNum;
			
			//Log.debug("in file simple name=" + inFile.getName());
			int index = inFile.getName().lastIndexOf(".");
			String imageName = inFile.getName().substring(0, index);
			
			int outFileNum = rowNum * columnNum;
			for (int i = 0; i < outFileNum; i++) {
				int columnIndex = i % columnNum;
				int rowIndex = i / columnNum;
				int x = columnIndex * singleWidth;
				int y = rowIndex * singleHeight;
				// 截取图片
				BufferedImage biOut = biIn.getSubimage(x, y, singleWidth, singleHeight);
				String outFileName = outPathName + imageName + i + ".png";
				Log.debug("i=" + i + ", columnIndex=" + columnIndex + ", rowIndex=" + rowIndex + ", x=" + x + ", y=" + y + ", outFileName=" + outFileName);
				// 保存图片
				ImageIO.write(biOut, "png", new File(outFileName));
			}
			
		} catch (Exception e) {
			Log.error(e.getLocalizedMessage());
		}
	}
	
	/**
	 * 切割图片
	 * 
	 * @param x
	 *            截点横坐标 (从左开始计数)
	 * @param y
	 *            截点纵坐标 (从上开始计数)
	 * @param width
	 *            截取的宽度
	 * @param height
	 *            截取的长度
	 * @param inFile
	 *            原始图片名称
	 * @param outFile
	 *            新生成的图片名称
	 */
	public static void cutImage(int x, int y, int width, int height, String inFile, String outFile) {
		try {
			BufferedImage bi = ImageIO.read(new File(inFile));
			
			int srcWidth = bi.getWidth(); // 得到源图宽
			int srcHeight = bi.getHeight(); // 得到源图长
			
			int newX = srcWidth - x;
			int newY = srcHeight - y;
			
			Log.debug("newX=" + newX + ", newY=" + newY + ", srcWidth=" + srcWidth + ", srcHeight=" + srcHeight);
			
			// 获取扩展名
			int index = inFile.lastIndexOf(".");
			String imgType = inFile.substring(index + 1);
			
			// 截取图片
			bi = bi.getSubimage(x, y, width, height);
			// 保存图片
			ImageIO.write(bi, imgType, new File(outFile));
		} catch(Exception e) {
			Log.error(e.getLocalizedMessage());
		}
		
	}
	
	/**
	 * 
	 * @param outFile
	 * @param rotated
	 * @param frameX
	 * @param frameY
	 * @param frameWidth
	 * @param frameHeight
	 * @param offsetX
	 * @param offsetY
	 * @param sourceSizeWidth
	 * @param sourceSizeHeight
	 * @param sourceColorRectX
	 * @param sourceColorRectY
	 * @param sourceColorRectWidth
	 * @param sourceColorRectHeight
	 */
	public static void cutImage(String inFile, String outFile, boolean rotated, int frameX, int frameY, int frameWidth, int frameHeight, int offsetX, int offsetY, 
			int sourceSizeWidth, int sourceSizeHeight, int sourceColorRectX, int sourceColorRectY, int sourceColorRectWidth, int sourceColorRectHeight) {
		
		Log.debug("cutImage : [ " + "inFile=" + inFile + ", outFile=" + outFile + ", rotated=" + rotated + ", frameX=" + frameX + ", frameY=" + frameY + 
				", frameWidth=" + frameWidth + ", frameHeight=" + frameHeight + ", offsetX=" + offsetX + ", offsetY=" + offsetY +
				", sourceSizeWidth=" + sourceSizeWidth + ", sourceSizeHeight=" + sourceSizeHeight + 
				", sourceColorRectX=" + sourceColorRectX + ", sourceColorRectY=" + sourceColorRectY +
				", sourceColorRectWidth=" + sourceColorRectWidth + ", sourceColorRectHeight=" + sourceColorRectHeight + "]");
		try {
			// 输入图片
			BufferedImage biIn = ImageIO.read(new File(inFile));
			
			// 截取图片
			if (rotated) {
				biIn = biIn.getSubimage(frameX, frameY, frameHeight, frameWidth);
				biIn = rotateImage(biIn, ROTATE_MODE_90CCW);
			} else {
				biIn = biIn.getSubimage(frameX, frameY, frameWidth, frameHeight);
			}
			
			// 获取图片描述
			int[] arrayIn = new int[biIn.getHeight() * biIn.getWidth()];
			biIn.getRGB(0, 0, biIn.getWidth(), biIn.getHeight(), arrayIn, 0, biIn.getWidth());
			
			// 输出图片
			BufferedImage biOut = new BufferedImage(sourceSizeWidth, sourceSizeHeight, BufferedImage.TYPE_INT_ARGB_PRE);
			biOut.setRGB(sourceColorRectX, sourceColorRectY, sourceColorRectWidth, sourceColorRectHeight, arrayIn, 0, sourceColorRectWidth);
			
			// 获取扩展名
			int index = inFile.lastIndexOf(".");
			String imgType = inFile.substring(index + 1);
						
			// 保存图片
			ImageIO.write(biOut, imgType, new File(outFile));
			
		} catch(Exception e) {
			Log.error(e.getLocalizedMessage());
		}
		
	}
	
	/**
	 * 旋转图片
	 * @param biIn
	 * @param angle
	 * @return
	 */
	public static final int ROTATE_MODE_180 = 1; // 旋转180度
	public static final int ROTATE_MODE_90CW = 2; // 旋转90度
	public static final int ROTATE_MODE_90CCW = 3; // 旋转-90度
	public static BufferedImage rotateImage(BufferedImage biIn, int mode) {
		// 初始化缓冲区
		BufferedImage biOut = null;
		// 旋转角度
		// 建立坐标变换用的类 
        AffineTransform trans = new AffineTransform();   
		if (mode == ROTATE_MODE_180) {
			// 将坐标转换器设置为旋转pi弧度（180）度，根据中心坐标旋转,这个坐标一般是图片缓冲坐标的一半
	        trans.rotate((Math.PI / 180) * 180, 0, 0); 
			biOut = new BufferedImage(biIn.getWidth(), biIn.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
		} else if (mode == ROTATE_MODE_90CW) {
			// 将坐标转换器设置为旋转pi弧度（180）度，根据中心坐标旋转,这个坐标一般是图片缓冲坐标的一半
	        trans.rotate((Math.PI / 180) * 90, 0, 0); 
			biOut = new BufferedImage(biIn.getHeight(), biIn.getWidth(), BufferedImage.TYPE_INT_ARGB_PRE);
		} else if (mode == ROTATE_MODE_90CCW) {
			// 将坐标转换器设置为旋转pi弧度（180）度，根据中心坐标旋转,这个坐标一般是图片缓冲坐标的一半
	        trans.rotate((Math.PI / 180) * -90, 0, 0); 
			biOut = new BufferedImage(biIn.getHeight(), biIn.getWidth(), BufferedImage.TYPE_INT_ARGB_PRE);
		} else {
			// 将坐标转换器设置为旋转pi弧度（180）度，根据中心坐标旋转,这个坐标一般是图片缓冲坐标的一半
	        trans.rotate((Math.PI / 180) * 0, 0, 0); 
			biOut = new BufferedImage(biIn.getWidth(), biIn.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
		}
		
		// 获取该缓冲区的画笔 Graphics2D  
        Graphics2D g2D = biOut.createGraphics();   
        // 设置画笔为旋转angle度的画笔  
        g2D.setTransform(trans); 
        
        if (mode == ROTATE_MODE_180) {
        	// 使用画笔将图片旋转后的图形画到图片缓冲bufImage中 
	        g2D.drawImage(biIn, -biIn.getWidth(), -biIn.getHeight(), biIn.getWidth(), biIn.getHeight(), null);
		} else if (mode == ROTATE_MODE_90CW) {
			// 使用画笔将图片旋转后的图形画到图片缓冲bufImage中 
	        g2D.drawImage(biIn, 0, -biIn.getHeight(), biIn.getWidth(), biIn.getHeight(), null);
		} else if (mode == ROTATE_MODE_90CCW) {
			// 使用画笔将图片旋转后的图形画到图片缓冲bufImage中 
	        g2D.drawImage(biIn, -biIn.getWidth(), 0, biIn.getWidth(), biIn.getHeight(), null);
		} else {
			// 使用画笔将图片旋转后的图形画到图片缓冲bufImage中 
	        g2D.drawImage(biIn, 0, 0, biIn.getWidth(), biIn.getHeight(), null);
		}
		
		return biOut;
	} 
	
}
